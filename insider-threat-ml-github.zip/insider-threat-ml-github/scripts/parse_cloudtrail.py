#!/usr/bin/env python3
"""Parse AWS CloudTrail JSON into a flat CSV."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import pandas as pd


def open_json(path: Path):
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as f:
            return json.load(f)
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def parse_records(input_path: str) -> pd.DataFrame:
    path = Path(input_path)
    payload = open_json(path)
    records = payload.get("Records", payload if isinstance(payload, list) else [])
    rows = []

    for r in records:
        user_identity = r.get("userIdentity", {}) or {}
        rows.append({
            "event_time": r.get("eventTime"),
            "event_source": r.get("eventSource"),
            "eventName": r.get("eventName"),
            "awsRegion": r.get("awsRegion"),
            "sourceIPAddress": r.get("sourceIPAddress"),
            "userAgent": r.get("userAgent"),
            "username": user_identity.get("userName") or user_identity.get("principalId"),
            "user_type": user_identity.get("type"),
            "account_id": user_identity.get("accountId"),
            "errorCode": r.get("errorCode"),
            "errorMessage": r.get("errorMessage"),
            "readOnly": r.get("readOnly"),
        })

    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Parse CloudTrail JSON or JSON.GZ to CSV.")
    parser.add_argument("--input", required=True, help="CloudTrail JSON or JSON.GZ file.")
    parser.add_argument("--output", required=True, help="Output CSV path.")
    args = parser.parse_args()

    df = parse_records(args.input)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.output, index=False)
    print(f"Parsed {len(df)} records to {args.output}")


if __name__ == "__main__":
    main()
