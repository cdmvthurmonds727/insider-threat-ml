# Contributing

Contributions are welcome for documentation, tests, detection logic, feature engineering, and visualization improvements.

## Development Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt -r requirements-dev.txt
pytest -q
```

## Pull Request Checklist

- Keep sample data synthetic or sanitized.
- Do not commit AWS credentials, account IDs, private keys, or real user data.
- Update documentation when changing pipeline behavior.
