---
name: Bug report
about: Report a problem with the insider threat ML pipeline
title: "[Bug]: "
labels: bug
assignees: ''
---

## Description

## Steps to Reproduce

## Expected Behavior

## Screenshots or Logs

## Environment
- OS:
- Python version:
