# GitHub Upload Guide

## Create the GitHub Repository

1. Go to GitHub.
2. Click **New repository**.
3. Name it `insider-threat-ml`.
4. Do not initialize with a README.

## Push from PowerShell

```powershell
cd insider-threat-ml-portfolio

git init
git add .
git commit -m "Initial portfolio release - Insider Threat ML"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/insider-threat-ml.git
git push -u origin main
```

## After Push

1. Replace `YOUR_USERNAME` in README badges and CODEOWNERS.
2. Add screenshots of output charts to the README if desired.
3. Enable GitHub Actions under the Actions tab.
4. Add repository topics:
   - aws
   - cloudtrail
   - cybersecurity
   - machine-learning
   - anomaly-detection
   - insider-threat
   - python
   - devsecops
