# Behavioral AI for Insider Threat Detection in AWS Cloud Systems

![Python](https://img.shields.io/badge/Python-3.10%2B-blue)
![AWS](https://img.shields.io/badge/AWS-CloudTrail%20%7C%20GuardDuty-orange)
![ML](https://img.shields.io/badge/ML-Isolation%20Forest-green)
![Security](https://img.shields.io/badge/Security-Insider%20Threat%20Detection-red)
![CI](https://github.com/YOUR_USERNAME/insider-threat-ml/actions/workflows/python-ci.yml/badge.svg)

## Project Overview

This portfolio project demonstrates a cloud security analytics pipeline for detecting anomalous user behavior in AWS environments. It parses AWS CloudTrail-style telemetry, engineers behavioral security features, trains an unsupervised Isolation Forest model, scores suspicious activity, and produces ranked anomaly output for security review.

The project was designed as a practical proof of concept for insider threat detection in cloud environments, especially environments where privileged access, off-hours activity, IAM changes, failed authentication attempts, and unusual data access patterns may indicate elevated risk.

## Why This Project Matters

Traditional security monitoring often relies on static rules. Insider threat behavior can be harder to detect because activity may come from valid user accounts. This project adds behavioral anomaly detection to help identify activity that is unusual relative to normal patterns.

## Key Features

- Parses AWS CloudTrail JSON and JSON.GZ logs into analysis-ready CSV files
- Engineers security-focused features from cloud activity logs
- Trains an Isolation Forest anomaly detection model
- Generates anomaly scores and severity labels
- Produces CSV outputs for analyst review
- Includes synthetic sample data for safe demonstration
- Includes GitHub Actions CI checks
- Includes documentation, architecture notes, and APA references

## Architecture

```mermaid
flowchart LR
    A[AWS CloudTrail Logs] --> B[CloudTrail Parser]
    B --> C[Feature Engineering]
    C --> D[Isolation Forest Model]
    D --> E[Anomaly Scoring]
    E --> F[Ranked Security Findings]
    F --> G[CSV Reports / Analyst Review]

    H[GuardDuty / IAM / EC2 / S3 Context] -. supports .-> C
```

## Repository Structure

```text
insider-threat-ml/
├── scripts/
│   ├── insider_threat_poc.py
│   ├── parse_cloudtrail.py
│   ├── feature_engineer_cloudtrail.py
│   ├── train_iforest.py
│   └── train_iforest_real.py
├── data/
│   └── sample/
│       └── sample_events.csv
├── docs/
│   ├── PROJECT_OVERVIEW.md
│   ├── RUNBOOK.md
│   ├── SECURITY_MODEL.md
│   ├── Appendix_Descriptions.md
│   └── references_apa.md
├── diagrams/
│   └── aws_architecture.mmd
├── tests/
│   └── test_smoke.py
├── .github/
│   ├── workflows/
│   │   └── python-ci.yml
│   └── ISSUE_TEMPLATE/
├── requirements.txt
├── requirements-dev.txt
├── Makefile
├── .gitignore
├── LICENSE
└── README.md
```

## Quick Start

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/insider-threat-ml.git
cd insider-threat-ml
```

### 2. Create a Python virtual environment

```bash
python3 -m venv .venv
source .venv/bin/activate
```

On Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 3. Install dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Run the demo pipeline

```bash
python scripts/insider_threat_poc.py --output-dir outputs
```

Expected outputs:

```text
outputs/insider_threat_results.csv
outputs/anomaly_events.csv
outputs/anomaly_score_distribution.png
outputs/severity_distribution.png
```

## Running With CloudTrail Logs

### Parse CloudTrail JSON

```bash
python scripts/parse_cloudtrail.py   --input data/cloudtrail/example.json.gz   --output outputs/parsed_cloudtrail.csv
```

### Engineer behavioral features

```bash
python scripts/feature_engineer_cloudtrail.py   --input outputs/parsed_cloudtrail.csv   --output outputs/features.csv
```

### Train and score anomalies

```bash
python scripts/train_iforest.py   --input outputs/features.csv   --output-dir outputs
```

## Detection Logic

The model evaluates behavioral signals such as:

- High API call volume
- Failed login attempts
- Privileged IAM or policy changes
- S3 access behavior
- Unique AWS service usage
- Off-hours activity
- Data transfer volume

The scoring layer converts anomaly indicators into analyst-friendly severity levels: Low, Medium, High, and Critical.

## Example Analyst Output

| User | API Calls | Failed Logins | Privileged Actions | Off-Hours | Severity |
|---|---:|---:|---:|---:|---|
| user7 | 32 | 5 | 4 | Yes | Critical |
| user12 | 21 | 3 | 2 | Yes | High |
| user2 | 9 | 1 | 1 | No | Medium |

## Skills Demonstrated

- Cloud security monitoring
- AWS CloudTrail log analysis
- Python data engineering
- Unsupervised machine learning
- Insider threat analytics
- Detection engineering
- GitHub Actions CI/CD
- Technical documentation
- Security-focused portfolio presentation

## Portfolio / Resume Summary

> Built a Python-based insider threat detection pipeline for AWS CloudTrail telemetry using feature engineering, Isolation Forest anomaly detection, severity scoring, and automated reporting. Packaged the project as a GitHub portfolio repository with documentation, CI checks, sample data, and cloud security architecture diagrams.

## Roadmap

- Add Streamlit dashboard for visual analyst workflow
- Add Dockerfile and docker-compose demo
- Add Terraform deployment for AWS lab environment
- Add GuardDuty finding enrichment
- Add SNS or Slack alerting for high-severity events
- Add model artifact versioning with joblib

## Disclaimer

This project is a proof of concept for academic, portfolio, and training use. It should be validated, tuned, and reviewed before use in production security operations.

## References

APA-formatted references are included in [`docs/references_apa.md`](docs/references_apa.md).
