from pathlib import Path
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_ROOT / "scripts"))

from insider_threat_poc import build_synthetic_dataset, severity_label, severity_score


def test_synthetic_dataset_has_expected_columns():
    df = build_synthetic_dataset(rows=50)
    expected = {"event_time", "user", "api_call_count", "failed_login_count", "is_known_threat"}
    assert expected.issubset(df.columns)
    assert len(df) == 50


def test_severity_label_thresholds():
    assert severity_label(10) == "Low"
    assert severity_label(40) == "Medium"
    assert severity_label(65) == "High"
    assert severity_label(90) == "Critical"


def test_severity_score_range():
    row = {
        "api_call_count": 50,
        "failed_login_count": 10,
        "privileged_action_count": 5,
        "iam_change_count": 3,
        "off_hours": 1,
        "data_transfer_gb": 30,
    }
    score = severity_score(row)
    assert 0 <= score <= 100
